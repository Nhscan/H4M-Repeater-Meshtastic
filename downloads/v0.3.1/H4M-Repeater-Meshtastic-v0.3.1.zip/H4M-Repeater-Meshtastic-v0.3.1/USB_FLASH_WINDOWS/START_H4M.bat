@echo off
setlocal
pushd "%~dp0"
echo H4M / HackRF One ONLY - custom Mayhem n_261109_ar04
echo.
echo 1. Close other SDR programs and connect just this HackRF by USB.
echo 2. Select HackRF mode on the H4M. After DFU recovery, it is already in that mode.
echo 3. Keep the USB cable connected until the read-back check completes.
echo.
pause
"utils\hackrf_info.exe"
if errorlevel 1 goto failed
if exist "H4M-before-flash.bin" goto backup_done
"utils\hackrf_spiflash.exe" -l 1048576 -r "H4M-before-flash.bin"
if errorlevel 1 goto failed
:backup_done
"utils\hackrf_spiflash.exe" -w "firmware\firmware_hackrf.bin"
if errorlevel 1 goto failed
"utils\hackrf_spiflash.exe" -l 1048576 -r "H4M-readback.bin"
if errorlevel 1 goto failed
fc /b "firmware\firmware_hackrf.bin" "H4M-readback.bin" >nul
if errorlevel 1 goto mismatch
echo.
echo SUCCESS: Flash read-back matches the custom firmware byte for byte.
echo Restart the H4M, check About shows n_261109_ar04, then open both TRX apps.
pause
popd
exit /b 0
:mismatch
echo ERROR: Flash read-back did not match. Do not assume installation succeeded.
goto finish_error
:failed
echo ERROR: USB operation failed. The new firmware has NOT been verified.
echo Check cable, HackRF mode and drivers. See START-HERE.txt for recovery.
:finish_error
pause
popd
exit /b 1
