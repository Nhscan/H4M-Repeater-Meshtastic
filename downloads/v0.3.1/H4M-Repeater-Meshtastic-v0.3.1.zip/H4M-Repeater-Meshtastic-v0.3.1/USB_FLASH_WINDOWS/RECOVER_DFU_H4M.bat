@echo off
setlocal
pushd "%~dp0"
echo H4M / HackRF One DFU recovery - use only if HackRF mode is unavailable.
echo Hold DFU, press and release RESET, then release DFU. Connect USB.
pause
"utils\dfu-util-static.exe" --device 1fc9:000c --alt 0 --download "firmware\hackrf_usb.dfu"
if errorlevel 1 goto failed
echo Leave USB connected. Waiting for the RAM-loaded HackRF firmware...
timeout /t 5 /nobreak >nul
call "START_H4M.bat"
set "FLASH_RESULT=%ERRORLEVEL%"
popd
exit /b %FLASH_RESULT%
:failed
echo DFU failed. Check DFU mode, USB cable and driver.
pause
popd
exit /b 1
